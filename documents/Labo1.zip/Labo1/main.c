#include "init.h"
#include <xc.h>


int main(void)
{
	oscillatorInit();

    // I. Configuration des sortie pour les LEDs
    TRISAbits.TRISA0 = 0;   // RA0, connect�e � une LED est configur�e en sortie
    TRISCbits.TRISC4 = 0;   // RC4, GPIO de la carte d'extension est configur�e en sortie (pour la led UB)
    
    // II. Configuration de RC1 en sortie
   	TRISCbits.TRISC1 = 0;
    // II. Configuration du timer2 � 10kHz
	PR2 = 3999;                 // T2=100us=(PR2+1)*25ns => PR2=3999
	T2CONbits.TON = 1;
    
    // III. Configuration de RA1 en sortie
   	TRISAbits.TRISA1 = 0;
    // III. Configuration du timer1 � 2Hz
    T1CONbits.TCKPS = 0b11;     // prescaler 256:1
	PR1 = 39062;                 // T1=250ms=(PR1+1)*25ns*256 => PR1=39062
	T1CONbits.TON = 1;

	while(1) {
        // I. Connexion entre RD7 et RA0 (LED de l'Explorer16)
        LATAbits.LATA0 = !PORTDbits.RD7;
        // I. Connexion entre RD7 et RC4 (LED UB)
        LATCbits.LATC4 = !PORTDbits.RD7;
        
        // II. Si le timer2 d�borde, on change l'�tat de RC1
        if (IFS0bits.T2IF) {
            IFS0bits.T2IF = 0;
            LATCbits.LATC1 = !LATCbits.LATC1;
        }

        // III. Si le timer1 d�borde, on change l'�tat de RA1
        if (IFS0bits.T1IF) {
            IFS0bits.T1IF = 0;
            LATAbits.LATA1 = !LATAbits.LATA1;
        }
	}
}
