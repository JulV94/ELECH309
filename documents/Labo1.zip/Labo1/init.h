/* 
 * File:   init.h
 * Author: Kevin De Cuyper
 *
 * Created on 29 janvier 2013, 14:34
 */

void oscillatorInit(void);
