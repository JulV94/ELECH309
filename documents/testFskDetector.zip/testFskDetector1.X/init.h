/* 
 * File:   Configuration.h
 * Author: M. Osee
 *
 * Created on 13 janvier 2013, 13:36
 */

#include "xc.h"

#define FCY 40000000

// configures the PLL
void init(void);
