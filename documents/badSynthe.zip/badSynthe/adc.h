/* 
 * File:   adc.h
 * Author: M. Os�e
 *
 * Last modification: 15/01/2016
 * Version 1.1: Ajout de la configuration du mode o� l'ADC1 est pilot� 
 * par le TIMER3.
 */

#ifndef ADC_H
#define	ADC_H


/**
 * En-t�te de la librairie de l'ADC pour les labos d'ELEC-H310 (et ELEC-H309)
 * 
 * Ces fonctions utilisent l'ADC1 du dsPIC de l'Explorer16 pour convertir la 
 * l'entr�e analogique AN0.
 */


/**
 * Initialise l'ADC1 pour convertir AN0, sur 10 bits, avec auto-sampling et 
 * d�marrage en software
 */
void adcPollingInit(void);

/**
 * Initialise l'ADC1 pour convertir AN0, sur 10 bits, avec auto-sampling et 
 * d�marrage par le d�bordement du TIMER3.
 * /!\ ATTENTION : cette fonction ne configure pas le TIMER3, il faut le faire 
 * s�par�ment.
  */void adcTimerInit(void);

/**
 * D�marre une conversion (pour le mode polling)
 */
void adcPollingStart(void);

/**
 * renvoie 1 si la conversion est termin�e, 0 sinon
 */
int adcConversionFinished(void);

/**
 * Renvoie le r�sultat de la derni�re conversion.
 * Si on essaie de lire pendant une conversion, la fonction le d�tecte et 
 * renvoie -32768, qui est une valeur impossible comme r�sultat de conversion.
 */
int adcRead(void);


#endif	/* ADC_H */

