#include "init.h"
#include "audio.h"
#include "lcd.h"
#include "clav.h"
#include "adc.h"
#include <xc.h>
#include <math.h>


#define SAMPLE_NB  50   // nombre d'�chantillons pour une p�riode de sinus


int main(void) {
    int voltage = 0;
    int wave[SAMPLE_NB];
    int i;
    char c, oldC = 'z';
    
    // I. Initialisation des p�riph�riques
    // On initialise l'oscillateur pour fonctionner � 40MHz
	oscillatorInit();
    // On configure la communication vers le DAC audio de la carte d'extension
    audioInit();
    // On configure les GPIOS du clavier
    clavInit();
    // On initialise l'ADC1 pour �tre pilot� par le TIMER3
    adcTimerInit();
    // On configure le TIMER3 pour d�border � 1kHz
 	PR3 = 39999;                 // T3=1ms=(PR2+1)*25ns => PR2=39999
	T3CONbits.TON = 1;
    // On configure le TIMER2 pour d�border � 20kHz. Il servira de base de
    // temps pour l'�criture dans le DAC audio
	PR2 = 1999;                 // T2=50us=(PR2+1)*25ns => PR2=1999
    // On configure les GPIOs connect�es aux LEDs
    TRISA = 0xFF00;             // configure RA0->RA7 en sortie
    
    // II. Initilisation des variables
    // On initialise le vecteur contenant le sinus � envoyer sur le DAC
    for (i=0; i<SAMPLE_NB; i++) {
        wave[i] = 2000*(1+sin(2*3.1416*i/SAMPLE_NB));
    }
    i = 0;
	while(1) {
        // I. Envoi d'un �chantillon au DAC
        if (IFS0bits.T2IF) {
            IFS0bits.T2IF = 0;
            audioWrite((long)wave[i++]*voltage/1024);
            if (i >= SAMPLE_NB) {
                i = 0;
            }
        }
        // II. Lecture du clavier
        // Cette fonction prend de 25us � 100us � s'ex�cuter.
        // Elle perturbe donc le timing qu'on voulait imposer avec le TIMER2
        c = readClav();
        if (c != oldC) {
            oldC = c;
            if (c == 'A') {
                T2CONbits.TON = !T2CONbits.TON;
            }
        }
        // III. Lecture du potentiom�tre
        if (adcConversionFinished()) {
            voltage = adcRead();
            if (voltage >= 0) {
                LATA = (1 << (9*voltage)/1024) - 1;
            }
        }
    }
}
