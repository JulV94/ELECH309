#include "init.h"
#include "audio.h"
#include "lcd.h"
#include "clav.h"
#include "adc.h"
#include <xc.h>


int main(void)
{
    int voltage;
    
	oscillatorInit();
    // I. Configuration des sorties pour les LEDs
    TRISA = 0xFF00;             // configure RA0->RA7 en sortie
    // II. Configuration de l'ADC
    adcPollingInit();
    // III. Configuration du TIMER2 � 1kHz
	PR2 = 39999;                 // T2=1ms=(PR2+1)*25ns => PR2=39999
	T2CONbits.TON = 1;

	while(1) {
        /* Si le timer 2 d�borde, on lance une conversion et on affiche
         * le r�sultat sur les LEDs */
        if (IFS0bits.T2IF) {
            IFS0bits.T2IF = 0;
            // I. Lancement de la conversion
            adcPollingStart();
            // II. On attend la fin de la conversion
            while (!adcConversionFinished());
            // III. On lit le r�sultat
            voltage = adcRead();
            // IV. S'il est valide, on l'affiche
            if (voltage >= 0) {
                LATA = (1 << (9*voltage)/1024) - 1;     // voir ci-dessous
            }
        }
	}
}


/* Explication du calcul pour l'affichage
 * I. N = (9*voltage)/1024
 *      On fait une conversion en 10 bits => 0 <= voltage <= 1023
 *      On veut diviser cet intervalle en 9, puisqu'il y a 9 �tats
 *      possibles de notre bargraph (de 0 � 8 LEDs allum�es).
 *      On obtient donc 0 <= N < 9
 *      En effet, 9*1023/1024 (= 8.99) = 8 dans le cas d'une division enti�re.
 *      Remarque : les parenth�ses permettent de s'assurer que la 
 *      multiplication est ex�cut�e avant la division.
 * 
 * II.  A = 1 << N
 *      << est l'op�rateur de d�calge vers la droite. On prend donc 1 et on le 
 *      d�cale de N bits vers la gauche.
 *      => A = 10........0      (A en binaire)
 *              [ N bits ]
 * 
 * III. LATA = A - 1
 *      => LATA = 01........1   (LATA en binaire)
 *                 [ N bits ]
 *      On obtient bien N bits � 1, avec 0 <= N <= 8 
*/