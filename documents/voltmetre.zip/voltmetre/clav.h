/* 
 * File:   clav.h
 * Author: Kevin De Cuyper
 *
 * Created on 29 janvier 2013, 14:21
 */


void clavInit(void);

char readClav( void );
